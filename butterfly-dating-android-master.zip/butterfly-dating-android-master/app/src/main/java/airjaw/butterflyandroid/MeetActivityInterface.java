package airjaw.butterflyandroid;

import android.net.Uri;

/**
 * Created by airjaw on 2/12/17.
 */

public interface MeetActivityInterface {
    public void downloadURLCompleted(Uri url);
}
