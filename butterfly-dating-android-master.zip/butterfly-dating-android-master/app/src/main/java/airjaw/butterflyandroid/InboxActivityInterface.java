package airjaw.butterflyandroid;

import android.net.Uri;

/**
 * Created by airjaw on 2/19/17.
 */

public interface InboxActivityInterface {
    public void downloadURLCompleted(Uri url);
}