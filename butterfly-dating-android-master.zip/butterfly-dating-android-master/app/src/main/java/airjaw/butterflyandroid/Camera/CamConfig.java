package airjaw.butterflyandroid.Camera;

/**
 * Created by airjaw on 2/17/17.
 */

public class CamConfig {

    public static final int MAX_VIDEO_DURATION = 5 * 1000;


}
