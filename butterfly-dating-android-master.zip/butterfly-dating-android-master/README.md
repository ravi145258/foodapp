# butterfly-dating-android
Butterfly Social / Dating app in Android/Java

http://joinbutterfly.com/android

This is a dating app with a mix of tinder and snapchat features.

Users post local viewable content, which disappear after 24 hours.

Other users can send a picture of themselves to posters of content. These media also disappear after 24 hours.

If users both like each other, a chat is opened up.

This app also features a custom camera, which is the only way to upload content, which ensures that all users are human.

Technical Section

Tools used:

This App is written in Java, with very few 3rd party libraries.
The backend utilizes Firebase Database and Firebase Storage.

Incomplete: Notifications
