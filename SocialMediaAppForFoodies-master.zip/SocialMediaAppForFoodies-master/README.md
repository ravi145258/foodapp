# SocialMediaAppForFoodies
This is a Social networking android app for food lovers. It is a way to connect with other foodies and grow your network of friends and followers. In this app we can, 
1.Users can create their own account and maintain it.
2.Post the Recipes with image and Description.
3.Followers can like and Comment on your post
4.Home screen with your and whom you follow posts.
5.Search and Follow other users
6.Current Location and nearby Restaurants
7.Uses Firebase as Database

Replace file google-services.json with your own firebase json file before executing the code
Details:
-Build on API 25: Android 7.1.1 (Nougat)
-Minimum SDK 21 is required
