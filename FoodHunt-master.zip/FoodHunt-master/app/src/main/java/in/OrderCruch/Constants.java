package in.OrderCruch;

/**
 * Created by gautam on 14/12/16.
 */

public class Constants {
    public static final String base_url="http://www.aniketvishal.com";
    public static final String getproductdetail="getproductdetail";
    public static final String addtocart="addtocart";
    public static final String showcart="showcart";
    public static final String removecart="removecart";
    public static final String search="search";
    public  static final String loadcomment="loadcomment";
    public static final String addcomment="addcomment";

    public static final String editComment="editcomment";
    public static final String deletecomment="deletecomment";
    public static final String ordercart="ordercart";
    public static final String getfromcategory="getfromcategory";
    public static final String loginoperation="login";
    public static final String SUCCESS="success";
    public static final String EMAIL = "email";


    public static final String VERIFYOTP_OPERATION="verifyOtp";
    public static final String RESENDOTP_OPERATION="resendOtp";
    public static final String makebill="makebill";

    public static final String PID = "p_id";
    public static final String NAME = "Name";
    public static final String RESTURANT = "Resturant";
    public static final String MARUFAZ_SLID = "marufaz_slid";
    public static final String MARUFAZ_CAR = "marufaz_car";
    public static String visiblity="visibility";
    public static String comment="comment";
    public static String rateit="rateit";
    public static String loadrating="loadrating";
    public static String loadcommentten="loadcommentten";
    public static String updaterating="updaterating";
    public static String gettoprated="gettoprated";



    public static final String REGISTER_OPERATION = "register";
    public static final String LOGIN_OPERATION = "login";
    public static final String CHANGE_PASSWORD_OPERATION = "chgPass";
    public static final String REDEEM_OPERATION="redeem";

    public static final String UPDATE_OPERATION="updateProfile";
    public static final String TRANSFER_POINTS="transferpts";
    public static final String UPDATEPTS="updatepts";
    public static final String getfromPid="getfromPid";
    public static final String getsubproducts="getsubproducts";

    public static final String cartnoi="cartnoi";





    public static final String FAILURE = "failure";
    public static final String IS_LOGGED_IN = "isLoggedIn";


    public static final String UNIQUE_ID = "unique_id";
    public static final String WALLET = "money";
    public static final String DOB = "dob";
    public static final String PLACE = "place";

    public static final String TAG = "ABILYTICS";
    public static final String RESET_PASSWORD_INITIATE = "forget";
    public static final String RESET_PASSWORD_FINISH = "checkOtpPassword";


    public static String getspecial="getspecial";
    public static String getcar="getcar";
}
